//
//  Packet.cpp
//  srv-fire
//
//  Created by Alexandre Bouvier on 13/03/2018.
//  Copyright © 2018 Alexandre Bouvier. All rights reserved.
//

#include <cstring>
#include <fcntl.h>
#include "../include/PacketHandler.h"

PacketHandler::PacketHandler(const std::string& url) : ANetwork(url)
{
    _embededSocket = -1;
    _cameraSocket = -1;
}

bool PacketHandler::getDataBaseEmebedded(std::string embededId) {
    std::map<std::string, std::string>  response;
    std::string                         ApiAnswer;
    std::map<std::string, std::string>  querry;

    querry["user_id"] = _userId;
    if (embededId.empty()) {
        querry["user_id"] = _userId;
        ApiAnswer = sendRequest("Embedded/create.php", getAsJson(querry));
        response = getFromJson(ApiAnswer);
        if (response.find("id") == response.end())
            return false;
        embededId = response["id"];
        sendPacket(ApiAnswer, getEmbeded());
    }
    else {
        querry["id"] = embededId;
        response = getFromJson(sendRequest("Embedded/embedded.php?id=" + embededId));
        if (response.find("id") == response.end())
            return false;
    }
    _embeddedId = response["id"];
    return true;
}

bool PacketHandler::createDataBaseSession() {
    std::map<std::string, std::string>  response;
    std::map<std::string, std::string>  querry;

    querry["embedded_id"] = _embeddedId;
    querry["start"] = getDateFormat();
    querry["finish"] = getDateFormat();
    querry["location"] = "43.335213,5.393734";
    response = getFromJson(sendRequest("Session/create.php", getAsJson(querry)));
    if (response.end() == response.find("id"))
        return false;
    _sessionId = response["id"];
    return true;
}

bool PacketHandler::initAPIData(std::string embededId) {
    std::map<std::string, std::string>  response;

    if (!getDataBaseEmebedded(embededId))
        return false;
    if (!createDataBaseSession())
        return false;
    return true;
}

bool PacketHandler::getImageFromCamera(std::map<std::string, std::string> Json) {
    static std::string path = "../imageAnalyzing/output/image/tmp";
    char *buff;
    int     toRead = -1;
    char    *img;
    FILE*   file;
    size_t size;

    path += std::to_string(rand() % 10 + 48);
    size = std::stoi(Json["Size"]);
    img = new char[1];
    buff = new char[size];
    sendPacket("OK", getEmbeded());
    while ( ++toRead < size && read(getEmbeded(), img, 1) > 0) {
        buff[toRead] = *img;
        img = new char[1];
    }
    buff[toRead] = *img;
    std::cout << "received : " << std::endl << buff << std::endl;
    std::cout << "Saving image to path : " << path << std::endl;
    if (!(file = fopen((path + ".png").c_str(), "wb")))
        return false;
    if (fwrite(buff, 1, size, file) <= 0 || fflush(file) <= 0 || fclose(file) <= 0)
        return false;
    return createImageRecord(path);
}

bool PacketHandler::createImageRecord(std::string path) {
    time_t rawtime;
    std::map<std::string, std::string> Json;
    struct tm * timeinfo;
    char dateAff [83];

    time (&rawtime);
    timeinfo = localtime (&rawtime);

    Json["path"] = path;
    Json["session_id"] = _sessionId;
    Json["online"] = Json["true"];
    Json["date"] = getDateFormat();
    std::cout << getAsJson(Json) << std::endl;
    Json = getFromJson(sendRequest("Camera/create.php", getAsJson(Json)));
    if (Json["code"] != "200")
        return false;
    return true;
}

bool PacketHandler::createSensorRecord(std::map<std::string, std::string> Json) {
    time_t rawtime;
    struct tm * timeinfo;
    char dateAff [83];

    time (&rawtime);
    timeinfo = localtime (&rawtime);

    Json["name"] = Json["Sensor"];
    Json.erase("Sensor");
    Json["session_id"] = _sessionId;
    Json["unit"] = Json["Unit"];
    Json.erase("Unit");
    Json["value"] = Json["Value"];
    Json.erase("Value");
    Json["online"] = Json["Online"];
    Json.erase("Online");
    Json["date"] = getDateFormat();
    std::cout << getAsJson(Json) << std::endl;
    Json = getFromJson(sendRequest("Sensor/create.php", getAsJson(Json)));
    if (Json.find("code") == Json.end())
        return false;
    return true;
}
std::string  PacketHandler::getPacket(int fd)
{
    size_t size;
    size_t pos;
    std::string back;
    char    buffer[2];

    memset(buffer, 0, 2);
    while ((size = static_cast<size_t>(read(fd, buffer, 1))) > 0)
    {
        back += std::string(buffer);
        memset(buffer, 0, 2);
        if ((pos = back.find('\n')) != std::string::npos) {
            back.erase(pos);
            return (back);
        }
    }
    return ("ERROR");
}

bool PacketHandler::initAPIConnection() {
    userInf["user_name"] = "Scaduto";
    userInf["password"] = "test";
    userInf = getFromJson(sendRequest("/connect.php", getAsJson(userInf)));
    if (userInf.find("token") != userInf.end()) {
        _tokenJWT = userInf["token"];
        _userId = userInf["user_id"];
        return true;
    }
    return (false);
}

void    PacketHandler::sendPacket(std::string toSend, int fd)
{
    write(fd, std::string(toSend + "\n").c_str(), toSend.size() + 1);
}

std::string PacketHandler::sendRequest(const std::string road, const std::string& body) {
    curlpp::Cleanup clean;
    curlpp::Easy r;
    std::string     back;
    std::list<std::string>  header;

    if (!_tokenJWT.empty())
        header.push_back("Authorization: " + _tokenJWT);
    if (road.find("?") != std::string::npos)
        header.push_back("TYPE: " + std::string("GET"));
    std::cout << _url + road << std::endl;
    r.setOpt(new curlpp::options::Url(_url + road));
    if (!_tokenJWT.empty())
        r.setOpt(new curlpp::options::HttpHeader(header));
    r.setOpt(new curlpp::options::PostFields(body));
    r.setOpt(new curlpp::options::PostFieldSize(body.length()));

    std::ostringstream response;
    r.setOpt(new curlpp::options::WriteStream(&response));

    r.perform();
    back = response.str();
    if (back.at(back.size() - 1) == '\n')
        back.erase(back.size() - 1);
    std::cout << back << std::endl;
    return back;
}

void PacketHandler::quit() {
    if (_embededSocket > 0)
        close(_embededSocket);
}

std::string PacketHandler::getAsJson(std::map<std::string, std::string> arg) {
    std::string Json = "{";

    for (auto it : arg) {
        Json += R"(")";
        Json += it.first;
        Json += R"(": )";
        Json += R"(")";
        Json += it.second;
        Json += R"(", )";
    }
    Json.erase(Json.size() - 2, Json.size());
    Json += "}";

    return Json;
}

std::map<std::string, std::string>  PacketHandler::getKeyAndVal(std::string Json, std::map<std::string, std::string> data, size_t pos) {
    std::string key;
    std::string val;
    size_t  pos2;

    if ((pos2 = Json.find(':')) == std::string::npos || pos2 > pos)
        return data;
    if (Json.at(pos) == '}') {
        Json.erase(pos, 1);
    }
    key = (std::string(Json)).substr(0, pos2 - 1);
    val = (std::string(Json)).substr(pos2 + 1, (pos) - (pos2 + 1));
    while (key.at(0) == ' ' || key.at(0) == '\"')
        key.erase(0, 1);
    while (key.at(key.size() - 1) == ' '|| key.at(key.size() - 1) == '\"')
        key.erase(key.size() - 1, 1);
    while (val.at(0) == ' ' || val.at(0) == '\"')
        val.erase(0, 1);
    while (val.at(val.size() - 1) == ' '|| val.at(val.size() - 1) == '\"')
        val.erase(val.size() - 1, 1);
    data[key] = val;
    return data;
}

std::map<std::string, std::string>  PacketHandler::getFromJson(std::string Json) {
    std::map<std::string, std::string>  data;
    size_t  pos;

    if (Json.at(0) != '{' || Json.at(Json.size() - 1) != '}')
        return data;
    Json.erase(0, 1);
    while ((pos = Json.find(',')) != std::string::npos) {
        data = getKeyAndVal(Json, data, pos);
        Json.erase(0, pos + 1);
    }
    data = getKeyAndVal(Json, data, Json.size() - 1);
    return data;
}

std::string PacketHandler::getDateFormat() {
    time_t rawtime;
    struct tm * timeinfo;
    char dateAff [83];

    time (&rawtime);
    timeinfo = localtime (&rawtime);

    strftime(dateAff, 83,"%Y-%m-%d %H:%M:%S+00",timeinfo);
    return dateAff;
}

const std::string &PacketHandler::get_tokenJWT() const {
    return _tokenJWT;
}

void PacketHandler::set_tokenJWT(const std::string &_tokenJWT) {
    PacketHandler::_tokenJWT = _tokenJWT;
}

const std::string &PacketHandler::get_userId() const {
    return _userId;
}

void PacketHandler::set_userId(const std::string &_userId) {
    PacketHandler::_userId = _userId;
}

const std::string &PacketHandler::get_embeddedId() const {
    return _embeddedId;
}

void PacketHandler::set_embeddedId(const std::string &_embeddedId) {
    PacketHandler::_embeddedId = _embeddedId;
}

const std::string &PacketHandler::get_sessionId() const {
    return _sessionId;
}

void PacketHandler::set_sessionId(const std::string &_sessionId) {
    PacketHandler::_sessionId = _sessionId;
}
