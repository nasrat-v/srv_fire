//
//  connectionHandler.cpp
//  srv-fire
//
//  Created by Alexandre Bouvier on 12/03/2018.
//  Copyright © 2018 Alexandre Bouvier. All rights reserved.
//

#include "../include/connectionHandler.h"

loger Log;

connectionHandler::connectionHandler() : commandManager(_cli, _thread), _network("http://109.255.19.77:81/API/")
{
    readProperties();
    if (!_network.initAPIConnection())
        Log.log("API connection failed");
}

connectionHandler::~connectionHandler()
{
    close(_fdConnect);
}

void connectionHandler::readProperties() {

    std::ifstream    stream("../network/properties.txt");
    std::string      line;
    std::string      properties;
    std::size_t      pos;

    while (getline(stream, line)) {
        if ((pos = line.find('=')) != std::string::npos) {
            properties = line.substr(0, pos);
            std::string val  = line.substr(pos + 1, line.size());
            if (properties == "logOut") {
                int     logOut;
                if (val == "0")
                    Log.addFd(0);
                else if ((logOut = open(val.c_str(), O_CREAT | O_RDWR | O_APPEND, S_IRUSR | S_IWUSR)) > 0) {
                    Log.addFd(logOut);
                }
            }
            else if (properties == "port") {
                _port = std::stoi(val, nullptr);
            }
            else if (properties == "maxCli")
                _maxCli = std::stoi(val, nullptr);
        }

    }
}

bool    connectionHandler::sendPacket(int fd, std::string toSend)
{
    if (fstat(fd, new struct stat()) == -1) {
        close(fd);
        return false;
    }
    write(fd, std::string(toSend + "\n").c_str(), toSend.size() + 1);
    return true;
}

std::string  connectionHandler::getPacket(int fd)
{
    size_t size;
    size_t pos;
    std::string back = "";
    char    buffer[4096];

    memset(buffer, 0, 4096);
    while ((size = static_cast<size_t>(read(fd, buffer, 4095))) > 0)
    {
        back += std::string(buffer);
        memset(buffer, 0, 4095);
        if ((pos = back.find('\n')) != std::string::npos) {
            back.erase(pos);
            return (back);
        }
    }
    return ("ERROR");
}

bool connectionHandler::connectNewCli(char **env) {
    _connectionThread.emplace_back(&connectionHandler::addCli, this, env);
    return true;
}

bool     connectionHandler::addCli(char **env)
{
    int newSock;
    std::string type;
    std::string id;
    size_t pos;
    struct sockaddr_in  cliInf{};
    int size = sizeof(cliInf);

    if (!(newSock = accept(_fdConnect, (struct sockaddr *)&cliInf, (socklen_t*)&size))) {
        Log.log("Failed to connect client");
        return (false);
    }
    if (!sendPacket(newSock, "TYPE"))
        return false;
    Log.log("waiting for client type");
    if ((type = getPacket(newSock)) == "ERROR")
        return false;
    if ((pos = type.find('\n')) != std::string::npos)
        type.erase(pos);
    if (!sendPacket(newSock, "ID"))
        return false;
    Log.log("waiting for client ID");
    if ((id = getPacket(newSock)) == "ERROR")
        return false;
    if ((pos = id.find('\n')) != std::string::npos)
        id.erase(pos);
    _network.setEmbeded(newSock);
    _network.initAPIData(id);
    if (_cli.find(_network.get_embeddedId()) != _cli.end()) {
        if (type == "CAMERA")
            _cli[_network.get_embeddedId()]->launchCamera(newSock, env);
        else if (type == "EMBEDDED")
            _cli[_network.get_embeddedId()]->_network.setEmbeded(newSock);
        else if (type == "IA")
            _cli[_network.get_embeddedId()]->_network.setIA(newSock);
    }
    else {
        if (type == "CAMERA") {
            _network.setEmbeded(-1);
        }
        else if (type != "EMBEDDED") {
            Log.log("Wrong client type ID : " + id);
            return false;
        }
        _cli[_network.get_embeddedId()] = new BusinessLogicManager(_network, _network.get_embeddedId());
        if (type == "CAMERA")
            _cli[_network.get_embeddedId()]->launchCamera(newSock, env);
        _thread[_network.get_embeddedId()] = std::thread(&BusinessLogicManager::run, _cli[_network.get_embeddedId()], env);
    }
    Log.log(_network.get_embeddedId() + " " + type);
    return (true);
}

void    connectionHandler::setAllFd()
{
    FD_ZERO(&_rfds);
    FD_SET(_fdConnect, &_rfds);
    FD_SET(0, &_rfds);
}


void    connectionHandler::start(char **env) {
    std::string read;

    setAllFd();
    Log.log("Server Launched");
    while (select(sizeof(_rfds) * 8, &_rfds, nullptr, nullptr, nullptr)) {
        if (FD_ISSET(_fdConnect, &_rfds)) {
            Log.log("New cli connected");
            connectNewCli(env);
        }
        if (FD_ISSET(0, &_rfds)) {
            if ((read = getPacket(0)) == "ERROR")
                Log.log("Failed read command");
            if (!commandManager.treatCmd(_fdConnect, read))
                return ;
        }
        commandManager.killNotRunningThread();
        setAllFd();
    }
}

bool connectionHandler::initConnection() {
    int     need = 1;

    if ((_fdConnect = socket(AF_INET, SOCK_STREAM, 0)) < 0)
        if (setsockopt(_fdConnect, SOL_SOCKET, SO_REUSEADDR, &need, sizeof(int)) < 0) {
            Log.log("Error opening socket");
            return false;
        }
    _srvInf.sin_family = AF_INET;
    _srvInf.sin_addr.s_addr = INADDR_ANY;
    if (_port == -1) {
        Log.log("Invalid port");
        return false;
    }
    _srvInf.sin_port = htons(_port);
    if (bind(_fdConnect, (struct sockaddr*)&_srvInf, sizeof(_srvInf)) == -1) {
        Log.log("Bind failed");
        return false;
    }
    listen(_fdConnect, _maxCli);
    return true;
}
