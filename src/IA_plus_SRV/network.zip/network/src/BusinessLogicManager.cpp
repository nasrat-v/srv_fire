//
// Created by nasrat_v on 15/03/18.
//

#include "../include/BusinessLogicManager.hh"

BusinessLogicManager::BusinessLogicManager(PacketHandler networkCpy, const std::string& _id): _network(networkCpy)
{
    id = _id;
    std::cout << id << std::endl;
    running = true;
    _timer = std::thread(&BusinessLogicManager::time, this);
}

bool        BusinessLogicManager::checkCommand(std::string Command)
{
    std::map<std::string, std::string>  data;
    size_t  pos;

    if (Command == "EXIT" || Command == "ERROR") {
        exit();
        return true;
    }
    std::cout << Command << std::endl;
    data = _network.getFromJson(Command);
    if (data.find("Sensor") != data.end()) {
        if (!_network.createSensorRecord(data))
            Log.log("failed to upload data => " + _network.getAsJson(data));
    }
    if (data.find("Image") != data.end()) {
        std::cout << "Image received" << std::endl;
        if (!_network.getImageFromCamera(data))
            Log.log("failed to upload data => " + _network.getAsJson(data));
    }
    return false;
}

void BusinessLogicManager::setAllFd() {
    FD_ZERO(&_rfds);
    if (_network.getEmbeded() != -1)
        FD_SET(_network.getEmbeded(), &_rfds);
    if (_network.getCamera() != -1)
        FD_SET(_network.getCamera(), &_rfds);
}

void BusinessLogicManager::readEmbedded(int fd) {
    std::string cmd;

    if (!(cmd = _network.getPacket(fd)).empty()) {
        if (checkCommand(cmd))
            Log.log(cmd, id);
    }
}

void        BusinessLogicManager::run(char **env)
{
    while (running) {
        setAllFd();
        if (select(sizeof(_rfds) * 8, &_rfds, nullptr, nullptr, nullptr)) {
            setAllFd();
            std::cout << "Activity on an device" << std::endl;
            if (_network.getEmbeded() != -1 && FD_ISSET(_network.getEmbeded(), &_rfds)) {
                Log.log("Activity on Embedded");
                readEmbedded(_network.getEmbeded());
            }
            if (_network.getCamera() != -1 && FD_ISSET(_network.getCamera(), &_rfds)) {
                Log.log("Activity on camera");
                readEmbedded(_network.getCamera());
            }
        }
    }
}

void BusinessLogicManager::time() {

    auto start = std::chrono::system_clock::now();
    auto end = std::chrono::system_clock::now();

    while (running) {
        end = std::chrono::system_clock::now();
        if (( std::chrono::duration<double>(end-start)).count() > 5) {
            _network.sendPacket("Update Allsensor", _network.getEmbeded());
            start = std::chrono::system_clock::now();
        }
    }
}

void BusinessLogicManager::analyse(char **env)
{
    char    *str;

    str = new char[_network.get_embeddedId().size() + 1];
    for (int n = 0; n < _network.get_embeddedId().size(); n++) {
        std::cout << "n = " << n << std::endl;
        str[n] = _network.get_embeddedId().at(n);
        std::cout << "str de n : " << str[n] << std::endl;
    }
    char    *argv[] = {"./ia", str, NULL};

   execve(argv[0], argv , env);
}

void BusinessLogicManager::exit() {
    kill(_pid, SIGINT);
    _network.sendPacket("EXIT", _network.getEmbeded());
    _network.quit();
//    _timer.join();
    running = false;
}

BusinessLogicManager::~BusinessLogicManager()
= default;

bool BusinessLogicManager::isRunning() {
    return running;
}

void BusinessLogicManager::setId(const std::string& _id) {
    id = _id;
}

std::string BusinessLogicManager::getId() {
    return id;
}

void BusinessLogicManager::launchCamera(int newSock, char **env) {
    _network.setCamera(newSock);
    if ((_pid = fork()) == -1)
        Log.log("Unable to fork for camera");
    if (_pid == 0)
        return analyse(env);
}
