//
// Created by nasrat_v on 15/03/18.
//

#ifndef __OPENCV_TEST_BUSINESSLOGICMANAGER_HH__
# define __OPENCV_TEST_BUSINESSLOGICMANAGER_HH__

# define FILE_PATH  "/home/nasrat_v/Images/blue.jpg"
# define X_IMAGE_CLE    640
# define Y_IMAGE_CLE    480

#include "PacketHandler.h"
#include "../../Utilitary/loger.hpp"
#include <thread>
#include <signal.h>

extern loger Log;

class BusinessLogicManager
{
public:
    PacketHandler       _network;

    BusinessLogicManager(PacketHandler networkCpy, const std::string& _id);
    ~BusinessLogicManager();

    void                run(char **env);
    void                exit();

    bool                isRunning();
    void                setId(const std::string&);
    std::string                 getId();

    void                launchCamera(int, char**);

private:
    std::string                 id;
    bool                        running;

    int                         _pid;
    std::thread                 _timer;

    fd_set                      _rfds;

    void time();

    void    setAllFd();
    void    readEmbedded(int fd);
    bool checkCommand(std::string);

    void analyse(char **env);
};

#endif /* !__OPENCV_TEST_BUSINESSLOGICMANAGER_HH__ */
