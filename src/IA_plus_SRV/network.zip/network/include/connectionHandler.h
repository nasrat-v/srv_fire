//
//  connectionHandler.h
//  srv-fire
//
//  Created by Alexandre Bouvier on 12/03/2018.
//  Copyright © 2018 Alexandre Bouvier. All rights reserved.
//

#ifndef ConnectionHandler_h
#define ConnectionHandler_h

#include "BusinessLogicManager.hh"
#include "CommandAnalyzer.hh"
#include "../../Utilitary/loger.hpp"
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <functional>
#include <fstream>
#include <netdb.h>
#include <netinet/in.h>
#include <map>
#include <thread>
#include <vector>

class connectionHandler {
private:
    PacketHandler                           _network;
    CommandAnalyzer                         commandManager;
    int                                     _port = -1;
    int                                     _maxCli = 10;
    fd_set                                  _rfds;

    std::map<std::string, BusinessLogicManager*>    _cli;
    std::map<std::string, std::thread>              _thread;

    std::vector<std::thread>    _connectionThread;

    struct sockaddr_in                      _srvInf;
    int                                     _fdConnect;

    std::string     getPacket(int);
    bool           sendPacket(int fd, std::string toSend);

    bool            addCli(char **env);
    bool            connectNewCli(char **env);

    void           setAllFd();
    void    readProperties();

public:
    bool           initConnection();

    connectionHandler();
    ~connectionHandler();
    
    void    start(char **env);
};

#endif /* ConnectionHandler_h */
