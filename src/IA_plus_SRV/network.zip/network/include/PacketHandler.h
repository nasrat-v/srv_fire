//
//  Packet.hpp
//  srv-fire
//
//  Created by Alexandre Bouvier on 13/03/2018.
//  Copyright © 2018 Alexandre Bouvier. All rights reserved.
//

#ifndef PacketHandler_h
#define PacketHandler_h

#include "ANetwork.hpp"
#include <iostream>
#include <vector>
#include <thread>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

class PacketHandler: public ANetwork {
private:
    std::map<std::string, std::string>  userInf;
    std::string                         _tokenJWT;
    std::string                         _userId;
public:
    const std::string &get_tokenJWT() const;

    void set_tokenJWT(const std::string &_tokenJWT);

    const std::string &get_userId() const;

    void set_userId(const std::string &_userId);

    const std::string &get_embeddedId() const;

    void set_embeddedId(const std::string &_embeddedId);

    const std::string &get_sessionId() const;

    void set_sessionId(const std::string &_sessionId);

private:
    std::string                         _embeddedId;
    std::string                         _sessionId;

    std::string     getDateFormat();

    std::map<std::string, std::string>  getKeyAndVal(std::string Json, std::map<std::string, std::string>, size_t pos);
    bool           createImageRecord(std::string path);
public:
    explicit PacketHandler(const std::string& url);

    std::string getPacket(int fd);
    void    quit();

    void    sendPacket(std::string, int);
    std::string sendRequest(const std::string road, const std::string& body = "");

    bool    initAPIConnection();
    bool    initAPIData(std::string EmbededId);
    bool           getDataBaseEmebedded(std::string);
    bool           createDataBaseSession();
    bool           createSensorRecord(std::map<std::string , std::string> Json);
    bool           getImageFromCamera(std::map<std::string , std::string> Json);

    std::string getAsJson(std::map<std::string, std::string> arg);
    std::map<std::string, std::string>  getFromJson(std::string Json);
};
#endif /* PacketHandler_h */
